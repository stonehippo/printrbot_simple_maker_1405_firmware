#ifndef __DFU_BOOL_H__
#define __DFU_BOOL_H__

typedef enum {
    false = 0,
    true  = 1
} dfu_bool;

#endif
